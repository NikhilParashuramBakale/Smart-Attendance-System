https://github.com/davisking/dlib-models/blob/4e463cb7fcd2756884f96d202b6470841afa4c33/shape_predictor_68_face_landmarks.dat.bz2
---

https://github.com/davisking/dlib-models/blob/4e463cb7fcd2756884f96d202b6470841afa4c33/dlib_face_recognition_resnet_model_v1.dat.bz2
---
```bash
sudo apt update
sudo apt install -y build-essential cmake libopenblas-dev liblapack-dev \
    libx11-dev libgtk-3-dev libboost-python-dev python3-dev
```
---
