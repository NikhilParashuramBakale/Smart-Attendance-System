# Place all the images of the person along with their names written as the image name
